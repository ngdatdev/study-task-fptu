package model;


public interface DatabaseInfo {
    public static String DRIVERNAME="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String DBURL="jdbc:sqlserver://LAPTOP-7M53ESA2;databaseName=Rooms_YourID;encrypt=false;trustServerCertificate=false;loginTimeout=30;";
    public static String USERDB="sa";
    public static String PASSDB="zxcl123123";
   
}
